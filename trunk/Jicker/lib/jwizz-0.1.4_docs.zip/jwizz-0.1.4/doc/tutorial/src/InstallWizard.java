import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.reflect.*;
import javax.swing.*;
import net.javaprog.ui.wizard.*;

public class InstallWizard {
    public static void main(String[] args) {
        DataModel data = new DataModel();
        
        WizardModel model = new DefaultWizardModel(new Step[]{
            new WelcomeStep(),
            new LicenseStep(),
            new LocationStep(data),
            new FinishStep()
        });
        model.addWizardModelListener(new WizardModelListener() {
            public void wizardFinished(WizardModelEvent e) {
                //do something with the collected data.
            }

            public void wizardCanceled(WizardModelEvent e) {}
            public void stepShown(WizardModelEvent e) {}
            public void wizardModelChanged(WizardModelEvent e) {}
        });
        
        Wizard wizard = new Wizard(model, "Installation Wizard", 
                new ImageIcon("Host24.gif"));
        
        wizard.pack();
        wizard.setLocationRelativeTo(null);
        wizard.setVisible(true);
        System.exit(0);
    }
}

class WelcomeStep extends AbstractStep {
    public WelcomeStep() {
        super("Welcome", "This is the Installation Wizard");
    }
    
    protected JComponent createComponent() {
        JPanel stepComponent = new JPanel();
        stepComponent.add(
            new JLabel("<html>This wizard will guide you through the installation process.<p>"
                + "You can navigate through the steps using the buttons below.</html>"));
        return stepComponent;
    }

    public void prepareRendering() {}
}

class LicenseStep extends AbstractStep {
    protected JTextArea licenseArea = new JTextArea();
    
    public LicenseStep() {
        super("License Agreement", "Please read the license carefully");
    }
    
    protected JComponent createComponent() {
        JPanel stepComponent = new JPanel(new BorderLayout(0, 10));
        stepComponent.add(new JScrollPane(licenseArea));
        
        final JRadioButton noRadioButton = new JRadioButton(
                "No, I don't accept the license terms", true);
        final JRadioButton yesRadioButton = new JRadioButton(
                "Yes, I accept the license terms");
        
        ButtonGroup group = new ButtonGroup();
        group.add(noRadioButton);
        group.add(yesRadioButton);
        
        ActionListener buttonListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setCanGoNext(e.getSource() == yesRadioButton);
            }
        };
        noRadioButton.addActionListener(buttonListener);
        yesRadioButton.addActionListener(buttonListener);
        
        JPanel choicePanel = new JPanel(new GridLayout(2, 1, 0, 5));
        choicePanel.add(noRadioButton);
        choicePanel.add(yesRadioButton);
        stepComponent.add(choicePanel, BorderLayout.SOUTH);
        return stepComponent;
    }
    
    public void prepareRendering() {
        try {
            BufferedReader reader = new BufferedReader(
                new FileReader("../../../LICENSE"));
            String line;
            while ((line = reader.readLine()) != null) {
                licenseArea.append(line + "\r\n");
            }
            reader.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        setCanGoNext(false);
    }
}

class LocationStep extends AbstractStep {
    protected DataModel data;
    protected JTextField fileTextField = new JTextField();
    protected JFileChooser fc = new JFileChooser();
    
    public LocationStep(DataModel data) {
        super("Choose location", "Please choose the installation location");
        this.data = data;
    }
    
    protected JComponent createComponent() {
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        final JPanel stepComponent = new JPanel();
        stepComponent.setLayout(new BoxLayout(stepComponent, BoxLayout.Y_AXIS));
        stepComponent.add(Box.createVerticalGlue());
        JPanel inputPanel = new JPanel(new BorderLayout(5, 0));
        inputPanel.add(new JLabel("Directory:"), BorderLayout.WEST);
        inputPanel.add(fileTextField);
        JButton browseButton = new JButton("Browse...");
        browseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (fc.showOpenDialog(stepComponent) == JFileChooser.APPROVE_OPTION) {
                    fileTextField.setText(fc.getSelectedFile().getPath());
                }
            }
        });
        inputPanel.add(browseButton, BorderLayout.EAST);
        inputPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 
                inputPanel.getPreferredSize().height));
        stepComponent.add(inputPanel);
        stepComponent.add(Box.createVerticalGlue());
        Method method = null;
        try {
            method = fileTextField.getClass().getMethod("getText", null);
        } catch(NoSuchMethodException nsme) {}
        data.registerDataLookup("location", 
                new DefaultDataLookup(fileTextField, method, null));
        return stepComponent;
    }
    
    public void prepareRendering() {}
}

class FinishStep extends AbstractStep {
    public FinishStep() {
        super("Finish", "The installation will now be started");
    }
    
    protected JComponent createComponent() {
        JPanel stepComponent = new JPanel();
        stepComponent.add(
            new JLabel("<html>The installation wizard will now copy the necessary files<p>"
                + "to your hard drive. Please click \"Finish\".</html>"));
        return stepComponent;
    }
    
    public void prepareRendering() {
        setCanFinish(true);
    }
}
