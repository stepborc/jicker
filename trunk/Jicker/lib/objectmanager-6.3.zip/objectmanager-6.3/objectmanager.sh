java -jar objectmanager.jar
